import { prisma } from '@/backend/db/prisma';
import type { Gasto } from '@prisma/client';
import type { IGastoRepository, DatosCrearGasto, GastoConRelaciones } from '@/shared/repositories/IGastoRepository';

export class PrismaGastoRepository implements IGastoRepository {
  async crear(data: DatosCrearGasto, tx?: unknown): Promise<Gasto> {
    const client = tx as any || prisma;
    return client.gasto.create({ data });
  }
  async obtenerTodos(): Promise<GastoConRelaciones[]> {
    return prisma.gasto.findMany({
      orderBy: { creadoEn: 'desc' },
      include: {
        pagador: { select: { id: true, nombre: true } },
        grupo: { select: { id: true, nombre: true } },
        divisiones: { include: { usuario: { select: { id: true, nombre: true } } } },
      },
    }) as Promise<GastoConRelaciones[]>;
  }
  async obtenerPorId(id: string): Promise<GastoConRelaciones | null> {
    return prisma.gasto.findUnique({
      where: { id },
      include: {
        pagador: { select: { id: true, nombre: true } },
        grupo: { select: { id: true, nombre: true } },
        divisiones: { include: { usuario: { select: { id: true, nombre: true } } } },
      },
    }) as Promise<GastoConRelaciones | null>;
  }
}
